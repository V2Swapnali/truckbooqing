import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trans-register',
  templateUrl: './trans-register.component.html',
  styleUrls: ['./trans-register.component.css']
})
export class TransRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
