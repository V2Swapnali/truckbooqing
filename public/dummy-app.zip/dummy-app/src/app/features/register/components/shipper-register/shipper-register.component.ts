import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-shipper-register',
  templateUrl: './shipper-register.component.html',
  styleUrls: ['./shipper-register.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ShipperRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
